SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_empRegistration]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create procedure [dbo].[sp_empRegistration]
(
@firstName varchar(50),
@lastName varchar(50),
@EmailId varchar(50),
@password varchar(50),
@address text,
@totalExp varchar(50),
@functionalArea varchar(50),
@skillset text,
@basicEducation varchar(50),
@resumeUpload  text,
@resume text
)
as
begin
insert into  employeeRegistration
(
firstName ,
lastName ,
EmailId ,
password ,
address ,
totalExp ,
functionalArea ,
skillset ,
basicEducation ,
resumeUpload ,
resume 
)
values
(
@firstName ,
@lastName ,
@EmailId ,
@password ,
@address ,
@totalExp ,
@functionalArea ,
@skillset ,
@basicEducation ,
@resumeUpload ,
@resume 
)
end' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cliectRegistration]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[cliectRegistration](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[OrganisationName] [varchar](50) NULL,
	[UserName] [varchar](50) NULL,
	[password] [varchar](50) NULL,
	[CompanyDetails] [text] NULL,
	[ProjectTitle] [varchar](50) NULL,
	[ProjectDetails] [text] NULL,
	[ProjectPlane] [text] NULL,
	[outcomeTargate] [varchar](50) NULL,
	[ProjectExpediture] [int] NULL,
	[ReqiurementTools] [text] NULL,
	[sites] [varchar](50) NULL,
 CONSTRAINT [PK_cliectRegistration] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[projectDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[projectDetails](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[projectname] [varchar](50) NULL,
	[projectstatus] [varchar](50) NULL,
	[startdate] [varchar](50) NULL,
	[complitiondate] [varchar](50) NULL,
	[clientname] [varchar](50) NULL,
	[clientlocation] [varchar](50) NULL,
	[projectdescription] [text] NULL,
	[additionalInformation] [varchar](50) NULL,
	[EmployeeName] [varchar](50) NULL,
	[workingHours] [varchar](50) NULL,
 CONSTRAINT [PK_projectDetails] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[admin]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[admin](
	[UserName] [varchar](50) NULL,
	[password] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usersdetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[usersdetails](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [varchar](50) NULL,
	[lastname] [varchar](50) NULL,
	[username] [varchar](50) NOT NULL,
	[password] [varchar](50) NOT NULL,
	[authority] [varchar](50) NOT NULL,
	[phoneno] [varchar](50) NOT NULL,
	[email] [varchar](50) NOT NULL,
	[Dateofbirth] [varchar](50) NOT NULL,
	[securityquestion] [varchar](50) NOT NULL,
	[answer] [varchar](50) NOT NULL,
	[location] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[employeeRegistration]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[employeeRegistration](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[totalExp] [varchar](50) NULL,
	[functionalArea] [varchar](50) NULL,
	[skillset] [text] NULL,
	[projectdetails] [text] NULL,
	[basicEducation] [varchar](50) NULL,
	[resume] [text] NULL,
 CONSTRAINT [PK_employeeRegistration] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[clientdetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[clientdetails](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [varchar](50) NULL,
	[lastname] [varchar](50) NULL,
	[username] [varchar](50) NOT NULL,
	[password] [varchar](50) NOT NULL,
	[authority] [varchar](50) NOT NULL,
	[phoneno] [varchar](50) NOT NULL,
	[email] [varchar](50) NOT NULL,
	[Dateofbirth] [varchar](50) NOT NULL,
	[securityquestion] [varchar](50) NOT NULL,
	[answer] [varchar](50) NOT NULL,
	[location] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_clientRegistration]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE procedure [dbo].[sp_clientRegistration]
(
@OrganisationName varchar(50),
@UserName varchar(50),
@password varchar(50),
@CompanyDetails text,
@ProjectTitle varchar(50),
@ProjectDetails text,
@ProjectPlane text,
@outcomeTargate varchar(50),
@ProjectExpediture int,
@ReqiurementTools text,
@sites varchar(50),
@SaveFlag  varchar(50) output
)
as
begin
insert into  cliectRegistration
(
OrganisationName ,
UserName ,
password,
CompanyDetails ,
ProjectTitle ,
ProjectDetails ,
ProjectPlane ,
outcomeTargate ,
ProjectExpediture ,
ReqiurementTools ,
sites 
)
values
(
@OrganisationName ,
@UserName ,
@password,
@CompanyDetails ,
@ProjectTitle ,
@ProjectDetails ,
@ProjectPlane ,
@outcomeTargate ,
@ProjectExpediture ,
@ReqiurementTools ,
@sites 
)
end

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_projectDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE procedure [dbo].[sp_projectDetails]
(
@projectname  varchar(50),
@projectstatus varchar(50),
@startdate datetime,
@complitiondate datetime,
@clientname varchar(50),
@clientlocation varchar(50),
@projectdescription varchar(50),
@additionalInformation varchar(50),
@EmployeeName varchar(50),
@workingHours varchar(50),
@flag varchar(50) output
)
as
begin
insert into  projectDetails
(
projectname  ,
projectstatus,
startdate ,
complitiondate ,
clientname ,
clientlocation ,
projectdescription ,
additionalInformation,
EmployeeName ,
workingHours
)
values
(
@projectname  ,
@projectstatus,
@startdate ,
@complitiondate ,
@clientname ,
@clientlocation ,
@projectdescription ,
@additionalInformation ,
@EmployeeName ,

@workingHours
)
end

' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_adminLogin]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create   procedure [dbo].[sp_adminLogin]
(
@UserName varchar(50),
@password varchar(50)
)
as
begin
if exists(select * from admin where UserName=@UserName and password=@password)
select * from admin
end' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_CheckEmpLogin]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE  procedure [dbo].[sp_CheckEmpLogin]
(
@username varchar(50),
@password varchar(50)
)
as
begin
if exists(select * from usersdetails where username=@username and password=@password)
select * from usersdetails
end' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[empRegistration]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE procedure [dbo].[empRegistration]
(

@totalExp varchar(50),
@functionalArea varchar(50),
@skillset text,
@projectdetails text,
@basicEducation varchar(50),

@resume text,
@SaveFlag varchar(50) output
)
as
begin
insert into  employeeRegistration
(

totalExp ,
functionalArea ,
skillset ,
projectdetails,
basicEducation ,
resume 
)
values
(

@totalExp ,
@functionalArea ,
@skillset ,
@projectdetails,
@basicEducation ,
@resume 
)
end


' 
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_CheckClientLogin]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE  procedure [dbo].[sp_CheckClientLogin]
(
@username varchar(50),
@password varchar(50)
)
as
begin
if exists(select * from clientdetails where username=@username and password=@password)
select * from clientdetails
end' 
END
